#include<iostream>
using namespace std;
float grosssal(float basicsalary,float allowancep){
	return basicsalary+(basicsalary*allowancep/100);

}
float netsal(float grossalary,float deductionp){
	return grossalary-(grossalary*deductionp/100);
	
}
int main(){
	float basicsalary,allowancep,deductionp,grossalary,netsalary;
	cout<<"Enter basic salaray ";
	cin>>basicsalary;
	cout<<"Enter allowance percentage ";
	cin>>allowancep;
	cout<<"Enter deductionp ";
	cin>>deductionp;
	grosssal(basicsalary,allowancep);
	netsal(grossalary,deductionp);
	cout<<"Gross salary"<<grosssal<<endl;
	cout<<"Net salary "<<netsal;
	
}
