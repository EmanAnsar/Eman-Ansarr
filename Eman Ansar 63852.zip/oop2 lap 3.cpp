#include<iostream>
using namespace std;
struct employee{
	string name;
	int id;
	int sal;
};
void inputEmployeeData(employee employees[],int noemp){

for(int i=0;i<noemp;i++){
	cout<<"Enter employee details "<<i+1<<endl;
	cout<<"Name ";
	cin>>employees[i].name;
	cout<<"id ";
	cin>>employees[i].id;
	cout<<"sal";
	cin>>employees[i].sal;
}}
void displayEmployeeData(employee employees[],int noemp){
	for(int i=0;i<noemp;i++) {
 cout<<"id "<<employees[i].id<<"\n";
 cout<<"Name: "<<employees[i].name<<"\n";
 cout<<"sal "<<employees[i].sal << "\n";
 }
}
void HighestEmployeeSal(employee employees[],int noemp){
	int topsal=0;
	for(int i=0;i<noemp;i++){
		if(employees[i].sal>employees[topsal].sal){
			topsal=i;
		}
	}
	cout<<"Highestsalary"<<endl;
	cout<<"Highest salary"<<employees[topsal].sal;
	
}
int main(){
	int noemp;
	cout<<"Enter the number of employees";
	cin>>noemp;
	employee employees[noemp];
	inputEmployeeData(employees,noemp);
	displayEmployeeData(employees,noemp);
	HighestEmployeeSal(employees,noemp);
	return 0;
	}
