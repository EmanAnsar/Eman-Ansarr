#include<iostream>
using namespace std;
     void kmtoMiles(int KM){
     float c=KM*0.621;
     cout<<"Value in Miles is "<<c;}
     void CeltoFar(float Celcius){
     	int F=(Celcius*9/5)+32;
     	cout<<"Temperature in Farenheit "<<F;}
    void seconds(int seconds){
    	int min=(seconds%3600)/60;
    	int h=seconds/3600;
    	int s=(seconds%3600)%60;
    	cout<<"Seconds to Hours Minutes and Seconds "<<h<<"hrs "<<min<<"min "<<s<<"sec";
		}
	int main(){
	int choice,second;
	float km;
	float Celcius;
	cout<<"1.Kilometers to miless"<<endl;
	cout<<"2.Celcius to farenheit"<<endl;
	cout<<"3.Seconds into hours,minutes and second"<<endl;
	cout<<"Enter your choice=";
	cin>>choice;
	switch(choice){
		case 1:
			cout<<"Enter the value in kilometers"<<endl;
			cin>>km;
			kmtoMiles(km);
			break;
		case 2:
			cout<<"Enter the temperature in Celcius";
			cin>>Celcius;
			CeltoFar(Celcius);
			break;
		case 3:
			cout<<"Enter seconds ";
			cin>>second;
			seconds(second);
			break;
			
}
			}
